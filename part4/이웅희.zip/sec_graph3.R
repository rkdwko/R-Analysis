# 저수준 작도 함수
var1 <- 1:5
plot(var1)
segments(2,2,3,3)
arrows(5,5,4,4)
text(2,4,'labels')
text(3,2,"테스트",srt=45)

plot(1:15)
abline(h=8)    # 선 긋기
rect(1,5,3,8)    # 사각형 그리기
arrows(1,1,5,5)    # 화살표 그리기
text(8,9,"TEXT")    # 글자 쓰기
title("THIS IS TEST","SUB")    # 제목 표시하기

iris
View(iris)
# 1 품종별 6가지 산점도
attach(iris)
iris.split <- split(iris,Species)
iris.split
setosa = iris.split$setosa
versicolor = iris.split$versicolor
virginica = iris.split$virginica

par(mfrow=c(3,2))
plot(setosa$Sepal.Length, setosa$Sepal.Width,main="setosa Sepal",xlab='length',ylab='width',col='red')
plot(setosa$Petal.Length, setosa$Petal.Width,main="setosa Petal",xlab='length',ylab='width',col='blue')
plot(versicolor$Sepal.Length, versicolor$Sepal.Width,main="versicolor Sepal",xlab='length',ylab='width',col='green')
plot(versicolor$Petal.Length, versicolor$Petal.Width,main="versicolor Petal",xlab='length',ylab='width',col='violet')
plot(virginica$Sepal.Length, virginica$Sepal.Width,main="virginica Sepal",xlab='length',ylab='width',col='orange')
plot(virginica$Petal.Length, virginica$Sepal.Width,main="virginica Petal",xlab='length',ylab='width',col='gray')

# 2 품종별 평균치로 barplot 비교하기
par=(mfrow=c(1,1,1,1))
x <- matrix(c(5,4,3,2),2,2)
barplot(x,beside=T,names=c(setosa,versicolor), col=c("green","yellow"))
barplot(x,beside=T,names=(versicolor), col=c("red","blue"))
barplot(x,beside=T,names=(virginica), col=c("grey","violet"))
x
